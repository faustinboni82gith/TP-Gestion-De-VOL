#include <iostream>
#include <vector>
#include <string>
using namespace std;

enum StatutReservation { EN_ATTENTE, CONFIRMEE, PAYEE, ANNULEE };

class Passager {
private:
    int id;
    string nom;
    string prenom;
    string numPasseport;
public:
    Passager(int id, string nom, string prenom, string passeport) : id(id), nom(nom), prenom(prenom), numPasseport(passeport) {}
    int getId() const { return id; }
    string getNomComplet() const { return nom + " " + prenom; }
    void afficher() const { cout << "ID: " << id << " | " << nom << " " << prenom << " | Passeport: " << numPasseport << endl; }
};

class Vol {
private:
    string numeroVol;
    string origine;
    string destination;
    string date;
    int capacite;
    int placesReservees;
    double prix;
public:
    Vol(string num, string orig, string dest, string d, int cap, double p) : numeroVol(num), origine(orig), destination(dest), date(d), capacite(cap), placesReservees(0), prix(p) {}
    string getNumero() const { return numeroVol; }
    int getPlacesDisponibles() const { return capacite - placesReservees; }
    bool estDisponible() const { return placesReservees < capacite; }
    bool reserverPlace() { if (estDisponible()) { placesReservees++; return true; } return false; }
    void libererPlace() { if (placesReservees > 0) placesReservees--; }
    void afficher() const { cout << "Vol " << numeroVol << " : " << origine << " -> " << destination << " | Date: " << date << " | Prix: " << prix << " FCFA" << " | Dispo: " << getPlacesDisponibles() << "/" << capacite << endl; }
};

class Reservation {
private:
    int id;
    Passager* passager;
    Vol* vol;
    StatutReservation statut;
public:
    Reservation(int id, Passager* p, Vol* v) : id(id), passager(p), vol(v), statut(EN_ATTENTE) {}
    int getId() const { return id; }
    Passager* getPassager() const { return passager; }
    Vol* getVol() const { return vol; }
    StatutReservation getStatut() const { return statut; }
    void setStatut(StatutReservation s) { statut = s; }
    string statutToString() const {
        if (statut == EN_ATTENTE) return "En attente";
        if (statut == CONFIRMEE) return "Confirmee";
        if (statut == PAYEE) return "Payee";
        return "Annulee";
    }
    void afficher() const { cout << "Resa #" << id << " | Passager: " << passager->getNomComplet() << " | Vol: " << vol->getNumero() << " | Statut: " << statutToString() << endl; }
};

vector<Passager> passagers;
vector<Vol> vols;
vector<Reservation> reservations;
int idPassager = 1, idResa = 1;

int main() {
    int choix;
    vols.push_back(Vol("BJ101", "Cotonou", "Paris", "20-11-2026", 2, 350000));
    vols.push_back(Vol("BJ202", "Cotonou", "Natitingou", "15-11-2026", 50, 25000));

    do {
        cout << "\n===== TP GESTION DE VOL =====\n";
        cout << "1. Enregistrer un passager\n2. Ajouter un vol\n3. Afficher les vols disponibles\n4. Rechercher un vol\n";
        cout << "5. Effectuer une reservation\n6. Enregistrer un paiement\n7. Annuler une reservation\n8. Consulter les reservations\n9. Afficher infos d'une reservation\n10. Quitter\nChoix: ";
        cin >> choix;

        if (choix == 1) {
            string nom, prenom, passeport;
            cout << "Nom: "; cin >> nom;
            cout << "Prenom: "; cin >> prenom;
            cout << "Num Passeport: "; cin >> passeport;
            passagers.push_back(Passager(idPassager++, nom, prenom, passeport));
            cout << "Passager enregistre!\n";
        }
        else if (choix == 2) {
            string num, orig, dest, date;
            int cap;
            double prix;
            cout << "Numero Vol: "; cin >> num;
            cout << "Origine: "; cin >> orig;
            cout << "Destination: "; cin >> dest;
            cout << "Date: "; cin >> date;
            cout << "Capacite: "; cin >> cap;
            cout << "Prix: "; cin >> prix;
            vols.push_back(Vol(num, orig, dest, date, cap, prix));
            cout << "Vol ajoute!\n";
        }
        else if (choix == 3) {
            for (auto &v : vols) if (v.estDisponible()) v.afficher();
        }
        else if (choix == 4) {
            string num;
            cout << "Numero Vol a chercher: "; cin >> num;
            bool trouve = false;
            for (auto &v : vols) if (v.getNumero() == num) { v.afficher(); trouve = true; }
            if (!trouve) cout << "Vol introuvable\n";
        }
        else if (choix == 5) {
            int idP;
            string numVol;
            cout << "ID Passager: "; cin >> idP;
            cout << "Numero Vol: "; cin >> numVol;
            if (idP <= 0 || idP > (int)passagers.size()) { cout << "Passager introuvable\n"; continue; }
            Vol* volTrouve = nullptr;
            for (auto &v : vols) if (v.getNumero() == numVol) volTrouve = &v;
            if (!volTrouve || !volTrouve->estDisponible()) { cout << "Vol complet ou introuvable!\n"; continue; }
            bool deja = false;
            for (auto &r : reservations) {
                if (r.getPassager()->getId() == idP && r.getVol()->getNumero() == numVol && r.getStatut() != ANNULEE) { deja = true; break; }
            }
            if (deja) { cout << "Deja une reservation active pour ce vol!\n"; continue; }
            volTrouve->reserverPlace();
            reservations.push_back(Reservation(idResa++, &passagers[idP-1], volTrouve));
            cout << "Reservation reussie!\n";
        }
        else if (choix == 6) {
            int idR;
            cout << "ID Reservation a payer: "; cin >> idR;
            for (auto &r : reservations) if (r.getId() == idR) {
                if (r.getStatut() == ANNULEE) cout << "ERREUR: Reservation annulee, paiement impossible\n";
                else { r.setStatut(PAYEE); cout << "Paiement OK! Place confirmee\n"; }
            }
        }
        else if (choix == 7) {
            int idR;
            cout << "ID Reservation a annuler: "; cin >> idR;
            for (auto &r : reservations) if (r.getId() == idR) {
                if (r.getStatut() == PAYEE) cout << "Annulation PAYEE -> Remboursement prevu\n";
                r.setStatut(ANNULEE);
                r.getVol()->libererPlace();
                cout << "Reservation annulee.\n";
            }
        }
        else if (choix == 8) {
            for (auto &r : reservations) r.afficher();
        }
        else if (choix == 9) {
            int idR;
            cout << "ID Reservation: "; cin >> idR;
            for (auto &r : reservations) if (r.getId() == idR) r.afficher();
        }
    } while (choix != 10);
    return 0;
}
